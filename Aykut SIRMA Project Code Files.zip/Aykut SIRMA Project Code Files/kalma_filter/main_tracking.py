import cv2
import numpy as np

from kalman_filter import KalmanFilter

TITLE = "Object Tracking with Kalman Filter"
frame = None
bbox = None
kalman = None

def update_bbox(new_bbox):
    global bbox, kalman
    
    # Initialize Kalman filter if not already done
    if kalman is None:
        state_matrix = np.zeros((4, 1), np.float32)  # [x, y, delta_x, delta_y]
        estimate_covariance = np.eye(state_matrix.shape[0])
        transition_matrix = np.array([[1, 0, 1, 0],[0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)
        process_noise_cov = np.array([[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]], np.float32) * 0.001
        measurement_state_matrix = np.zeros((2, 1), np.float32)
        observation_matrix = np.array([[1,0,0,0],[0,1,0,0]],np.float32)
        measurement_noise_cov = np.array([[1,0],[0,1]], np.float32) * 1
        kalman = KalmanFilter(X=state_matrix,
                              P=estimate_covariance,
                              F=transition_matrix,
                              Q=process_noise_cov,
                              Z=measurement_state_matrix,
                              H=observation_matrix,
                              R=measurement_noise_cov)
    
    # Update Kalman filter with new measurement
    x, y, w, h = new_bbox
    current_measurement = np.array([[np.float32(x + w/2)], [np.float32(y + h/2)]])
    current_prediction = kalman.predict()
    kalman.correct(current_measurement)
    
    # Update bbox with filtered estimate
    current_estimate = kalman.X
    x, y = current_estimate[0], current_estimate[1]
    w, h = bbox[2], bbox[3]
    bbox = (int(x-w/2), int(y-h/2), w, h)

    return


def detect_objects(frame):
    # Perform object detection on frame
    # (Example: using TensorFlow 1's object detection API)
    detected_objects = tf1_object_detector.detect(frame)
    
    # Choose the closest detected object to the previous bbox
    closest_object = None
    min_distance = float('inf')
    for obj in detected_objects:
        x, y, w, h = obj.bbox
        distance = np.linalg.norm(np.array((x+w/2, y+h/2)) - np.array((bbox[0]+bbox[2]/2, bbox[1]+bbox[3]/2)))
        if distance < min_distance:
            closest_object = obj
            min_distance = distance
    
    # Update bbox with closest detected object
    update_bbox(closest_object.bbox)
    
    # Draw bbox on frame
    x, y, w, h = bbox
    cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
    
    return


# Real-Time Video feed from Webcam
video = cv2.VideoCapture(0)

while True:

    ret, frame = video.read()
    
    # check for frame if Nonetype
    if frame is None:
        break
    
        # Perform object detection and tracking
    if bbox is None:
        # If no bbox exists yet, simply detect objects
        detect_objects(frame)
    else:
        # Otherwise, track the object using Kalman filter
        detect_objects(frame)
    
    # Show the frame
    cv2.imshow(TITLE, frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cv2.destroyAllWindows()

