# Mouse Tracking with Kalman Filter
# Author: Aykut SIRMA
# Date: November 17, 2017

import cv2
import numpy as np

from kalman_filter import KalmanFilter

TITLE = "Mouse Tracking with Kalman Filter"

current_measurement = None
current_prediction = None

#frame = np.ones((800,800,3),np.uint8) * 255

"""
stateMatrix = np.zeros((4, 1), np.float32)  # [x, y, delta_x, delta_y]
estimateCovariance = np.eye(stateMatrix.shape[0])
transitionMatrix = np.array([[1, 0, 1, 0],[0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)
processNoiseCov = np.array([[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]], np.float32) * 0.001
measurementStateMatrix = np.zeros((2, 1), np.float32)
observationMatrix = np.array([[1,0,0,0],[0,1,0,0]],np.float32)
measurementNoiseCov = np.array([[1,0],[0,1]], np.float32) * 1
kalman = KalmanFilter(X=stateMatrix,
                      P=estimateCovariance,
                      F=transitionMatrix,
                      Q=processNoiseCov,
                      Z=measurementStateMatrix,
                      H=observationMatrix,
                      R=measurementNoiseCov)
"""

def mousemove(event, x, y, s, p):
    # To check mousemove() function is initiated or not
    #print("mousemove called")
    global frame, current_measurement, current_prediction, kalman
    current_measurement = np.array([[np.float32(x)], [np.float32(y)]])
    current_prediction = kalman.predict()

    cmx, cmy = current_measurement[0], current_measurement[1]
    cpx, cpy = current_prediction[0], current_prediction[1]

    frame = np.ones((800,800,3),np.uint8) * 255
    # TOP LEFT CORNER
    #cv2.putText(frame, "Measurement: ({:.1f}, {:.1f})".format(np.float(cmx), np.float(cmy)),
                #(30, 30), cv2.FONT_HERSHEY_DUPLEX, 0.8, (50, 150, 0))
    #cv2.putText(frame, "Prediction: ({:.1f}, {:.1f})".format(np.float(cpx), np.float(cpy)),
                #(30, 60), cv2.FONT_HERSHEY_DUPLEX, 0.8, (0, 0, 255))

    # Circle size is increased to 10
    #cv2.circle(frame, (int(cmx), int(cmy)), 10, (50, 150, 0), -1)      # current measured point
    #cv2.circle(frame, (int(cpx), int(cpy)), 10, (0, 0, 255), -1)      # current predicted point

    # BOTTOM LEFT CORNER
    cv2.putText(frame, "Measurement: ({:.1f}, {:.1f})".format(np.float(cmx), np.float(cmy)),
                (30, frame.shape[0] - 30), cv2.FONT_HERSHEY_DUPLEX, 0.8, (50, 150, 0))
    cv2.putText(frame, "Prediction: ({:.1f}, {:.1f})".format(np.float(cpx), np.float(cpy)),
                (30, frame.shape[0] - 60), cv2.FONT_HERSHEY_DUPLEX, 0.8, (0, 0, 255))

    # Circle size is lowered to 5
    cv2.circle(frame, (int(cmx), int(cmy)), 5, (50, 150, 0), -1)      # current measured point
    cv2.circle(frame, (int(cpx), int(cpy)), 5, (0, 0, 255), -1)      # current predicted point


    kalman.correct(current_measurement)

    return


cv2.namedWindow(TITLE)
cv2.setMouseCallback(TITLE, mousemove)

stateMatrix = np.zeros((4, 1), np.float32)  # [x, y, delta_x, delta_y]
estimateCovariance = np.eye(stateMatrix.shape[0])
transitionMatrix = np.array([[1, 0, 1, 0],[0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)
processNoiseCov = np.array([[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]], np.float32) * 0.001
measurementStateMatrix = np.zeros((2, 1), np.float32)
observationMatrix = np.array([[1,0,0,0],[0,1,0,0]],np.float32)
measurementNoiseCov = np.array([[1,0],[0,1]], np.float32) * 1
kalman = KalmanFilter(X=stateMatrix,
                      P=estimateCovariance,
                      F=transitionMatrix,
                      Q=processNoiseCov,
                      Z=measurementStateMatrix,
                      H=observationMatrix,
                      R=measurementNoiseCov)

# Real-Time Video feed from Webcam
video = cv2.VideoCapture(0)

while True:

    ret, frame = video.read()
    
    # check for frame if Nonetype
    if frame is None:
        break

    # Display measurement and prediction information on top of the video frame
    if current_measurement is not None and current_prediction is not None:
        cmx, cmy = current_measurement[0], current_measurement[1]
        cpx, cpy = current_prediction[0], current_prediction[1]

        # TOP LEFT CORNER
        #cv2.putText(frame, "Measurement: ({:.1f}, {:.1f})".format(np.float(cmx), np.float(cmy)),
                    #(30, 30), cv2.FONT_HERSHEY_DUPLEX, 0.8, (50, 150, 0))
        #cv2.putText(frame, "Prediction: ({:.1f}, {:.1f})".format(np.float(cpx), np.float(cpy)),
                    #(30, 60), cv2.FONT_HERSHEY_DUPLEX, 0.8, (0, 0, 255))

        # Circle size is increased to 10
        #cv2.circle(frame, (int(cmx), int(cmy)), 10, (50, 150, 0), -1)      # current measured point
        #cv2.circle(frame, (int(cpx), int(cpy)), 10, (0, 0, 255), -1)      # current predicted point

        # BOTTOM LEFT CORNER
        cv2.putText(frame, "Measurement: ({:.1f}, {:.1f})".format(np.float(cmx), np.float(cmy)),
                    (30, frame.shape[0] - 30), cv2.FONT_HERSHEY_DUPLEX, 0.8, (50, 150, 0))
        cv2.putText(frame, "Prediction: ({:.1f}, {:.1f})".format(np.float(cpx), np.float(cpy)),
                    (30, frame.shape[0] - 60), cv2.FONT_HERSHEY_DUPLEX, 0.8, (0, 0, 255))

        # Circle size is lowered to 5
        cv2.circle(frame, (int(cmx), int(cmy)), 5, (50, 150, 0), -1)      # current measured point
        cv2.circle(frame, (int(cpx), int(cpy)), 5, (0, 0, 255), -1)      # current predicted point
    
    cv2.imshow(TITLE,frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cv2.destroyAllWindows()
