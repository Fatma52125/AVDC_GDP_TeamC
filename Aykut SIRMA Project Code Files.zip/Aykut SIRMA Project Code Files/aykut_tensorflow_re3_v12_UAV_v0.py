######## Video Object Detection Using Tensorflow-trained Classifier #########
#
# Author: Aykut SIRMA
# Date: 12/15/2022
# Description: 
# This program uses a TensorFlow-trained classifier to perform object detection.
# It loads the classifier and uses it to perform object detection on a video.
# It draws boxes, scores, and labels around the objects of interest in each
# frame of the video or real-time video feed from webcam or camera.

# Import packages
import os
import cv2
import cvzone
import numpy as np
import tensorflow as tf
import sys
import time
import math
import numpy as np
import datetime
import argparse
import uuid
import glob
import operator
import imutils

from scipy.spatial import distance
from collections import OrderedDict

# Import utilites
from utils import label_map_util
from utils import visualization_utils as vis_util
from object_detection.utils import tensorflow_tracker
from utils import aykut_detector_utils as detector_utils
from utils import aykut_IouTracker as IouTracker
from utils import VehicleTracker
from tracker import *

from kalman_filter import KalmanFilter

from filterpy.kalman import UnscentedKalmanFilter
from filterpy.kalman import MerweScaledSigmaPoints
from filterpy.kalman import UKF
from filterpy.common import Q_discrete_white_noise

from centroidtracker import CentroidTracker

from videostabilizer import VideoStabilizer

np.set_printoptions(precision=6)
np.set_printoptions(suppress=True)

# Create tracker object
#tracker_Euclidean = EuclideanDistTracker()
tracker_vehicle = CentroidTracker(maxDisappeared=80, maxDistance=90)

# Name of the directory containing the object detection module we're using
#MODEL_NAME = 'inference_graph_iha'
#MODEL_NAME = 'inference_graph_iha_ssd_coco'
MODEL_NAME = 'inference_graph_UAV_ssd_inception_v2_coco'

#VIDEO_NAME = 'UAV_GP_Videos/output_360x640_20fps_test1.mp4'
#VIDEO_NAME = 'UAV_GP_Videos/output_360x640_30fps_test2.mp4'
#VIDEO_NAME = 'UAV_GP_Videos/output_360x640_60fps_test3.mp4'
#VIDEO_NAME = 'UAV_GP_Videos/output_1280x720_60fps_test4.mp4'
#VIDEO_NAME = 'UAV_GP_Videos/output_1280x720_60fps_test4_realtime.mp4'

#VIDEO_NAME = 'UAV_GP_Videos/test_video_1.mp4'
#VIDEO_NAME = 'UAV_GP_Videos/test_video_2.mp4'
#VIDEO_NAME = 'UAV_GP_Videos/test_video_3.mp4'
VIDEO_NAME = 'UAV_GP_Videos/test_video_4.mp4'
#VIDEO_NAME = 'UAV_GP_Videos/test_video_5.mp4'
#VIDEO_NAME = 'UAV_GP_Videos/test_video_6.mp4'

# Grab path to current working directory
CWD_PATH = os.getcwd()

# Path to frozen detection graph .pb file, which contains the model that is used
# for object detection.
PATH_TO_CKPT = os.path.join(CWD_PATH,MODEL_NAME,'frozen_inference_graph.pb')

# Path to label map file
PATH_TO_LABELS = os.path.join(CWD_PATH,'training_uav','labelmap.pbtxt')
#PATH_TO_LABELS = os.path.join(CWD_PATH,'training_iha_ssd_coco','labelmap.pbtxt')

# Path to video
PATH_TO_VIDEO = os.path.join(CWD_PATH,VIDEO_NAME)

# Number of classes the object detector can identify
NUM_CLASSES = 16

TITLE = "Object Tracking and Mouse Tracking with Kalman Filter "
# frame = np.ones((800,800,3),np.uint8) * 255

# Kalman Filter used for mouse() function
current_measurement = None
current_prediction = None
kalman = None

###########################################################
# Real-Time Video feed to capture from Webcam
# Load the input image from webcam
#video = cv2.VideoCapture(0)

# Open video file
video = cv2.VideoCapture(PATH_TO_VIDEO)
video = VideoStabilizer(video)
frame = video.read()

##################################################################################################################
# Initialize variables for tracking
prev_xmin = -1  # Initialize prev_xmin to a default value
prev_ymin = -1  # Initialize prev_ymin to a default value

# Define a global counter variable to assign unique IDs to cars
CAR_ID_COUNTER = 0

# To assign a unique ID for each detected object that will not repeat, you can use a counter variable that increments each time a new object is detected.
object_counter = 0

object_id = 0  # Initialize the object ID for single target
object_id_track = 0  # Initialize the object ID for single target

# Define a list to store the object IDs for each detected object
object_ids = []
tracked_objects = {}

# Initialize an empty dictionary to store object IDs and their corresponding bounding box coordinates
object_dict = {}
threshold = 30  # Failure detection threshold


############################################

# Define the Simplex font for displaying the object IDs
_SIMPLEX = (cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

# Initialize the UKF parameters
dim_x = 4  # State vector dimension (x, y, x_dot, y_dot)
dim_z = 2  # Measurement vector dimension (x, y)
dt = 1.0 / 30  # Time step
points = MerweScaledSigmaPoints(n=dim_x, alpha=0.1, beta=2.0, kappa=0.0)
ukf = UnscentedKalmanFilter(dim_x=dim_x, dim_z=dim_z, dt=dt, fx=None, hx=None, points=points)


# Kalman Filter
stateMatrix = np.zeros((4, 1), np.float32)  # [x, y, delta_x, delta_y]
estimateCovariance = np.eye(stateMatrix.shape[0])
transitionMatrix = np.array([[1, 0, 1, 0],[0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)
processNoiseCov = np.array([[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]], np.float32) * 0.001
measurementStateMatrix = np.zeros((2, 1), np.float32)
observationMatrix = np.array([[1,0,0,0],[0,1,0,0]],np.float32)
measurementNoiseCov = np.array([[1,0],[0,1]], np.float32) * 1
kalman = KalmanFilter(X=stateMatrix,
                      P=estimateCovariance,
                      F=transitionMatrix,
                      Q=processNoiseCov,
                      Z=measurementStateMatrix,
                      H=observationMatrix,
                      R=measurementNoiseCov)


# Initialize the Kalman Filter
kf = cv2.KalmanFilter(4, 2)
kf.measurementMatrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], np.float32)
kf.transitionMatrix = np.array([[1, 0, 1, 0], [0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)
kf.processNoiseCov = np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32) * 0.03
kf.measurementNoiseCov = np.array([[1, 0], [0, 1]], np.float32) * 0.00003

# Initialize a list to store the Kalman filter objects
kalman_filters = []
#kalman_filters = {}

################################################################################################################################
# Initiliaze Tensorflow GPU
"""
if tf.test.gpu_device_name(): 
    print('Default GPU Device: {}'.format(tf.test.gpu_device_name()))
else:
    print("Please install GPU version of TF")
"""

config = tf.ConfigProto()
config.gpu_options.allow_growth=True
sess = tf.Session(config=config)


if tf.test.gpu_device_name(): 
    print('Default GPU Device: {}'.format(tf.test.gpu_device_name()))
else:
    print("Please install GPU version of TF")

#############################################
# Load the label map.
# Label maps map indices to category names, so that when our convolution
# network predicts `4`, we know that this corresponds to `car`.
# Here we use internal utility functions, but anything that returns a
# dictionary mapping integers to appropriate string labels would be fine
label_map = label_map_util.load_labelmap(PATH_TO_LABELS)
categories = label_map_util.convert_label_map_to_categories(label_map, max_num_classes=NUM_CLASSES, use_display_name=True)
category_index = label_map_util.create_category_index(categories)

#############################################
# Load the Tensorflow model into memory.
detection_graph = tf.Graph()
with detection_graph.as_default():
    od_graph_def = tf.GraphDef()
    with tf.gfile.GFile(PATH_TO_CKPT, 'rb') as fid:
        serialized_graph = fid.read()
        od_graph_def.ParseFromString(serialized_graph)
        tf.import_graph_def(od_graph_def, name='')

    sess = tf.Session(graph=detection_graph)
#############################################

#######################################################################################################################
# Define input and output tensors (i.e. data) for the object detection classifier
# Input tensor is the image
# 0)
image_tensor = detection_graph.get_tensor_by_name('image_tensor:0')

# Output tensors are the detection boxes, scores, and classes # Extract the relevant information from the output
# Each box represents a part of the image where a particular object was detected
# 1)
detection_boxes = detection_graph.get_tensor_by_name('detection_boxes:0')

# Each score represents level of confidence for each of the objects.
# The score is shown on the result image, together with the class label.
# 2)
detection_scores = detection_graph.get_tensor_by_name('detection_scores:0')
# 3)
detection_classes = detection_graph.get_tensor_by_name('detection_classes:0')

# Number of objects detected
# 4)
num_detections = detection_graph.get_tensor_by_name('num_detections:0')

# Store the extracted information in the detection_output variable
detection_output = {
    'detection_boxes': detection_boxes,
    'detection_scores': detection_scores,
    'detection_classes': detection_classes
}
#######################################################################################################################

# Number of frames to capture
num_frames = 1 # the dataset had made for one frame per second so we make it "1" here


###########
# Check the current resolution of the camera
#width = video.get(cv2.CAP_PROP_FRAME_WIDTH)
#height = video.get(cv2.CAP_PROP_FRAME_HEIGHT)

# Print the current resolution
#print("Current webcam resolution: {} x {}".format(int(width), int(height)))
###########

###########
# Set the resolution to 1920 x 1080
#video.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
#video.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)

# Check the current resolution of the camera
#width = video.get(cv2.CAP_PROP_FRAME_WIDTH)
#height = video.get(cv2.CAP_PROP_FRAME_HEIGHT)

# Print the current resolution
#print("Current webcam resolution: {} x {}".format(int(width), int(height)))
###########

def non_max_suppression_fast(boxes, overlapThresh):
    try:
        if len(boxes) == 0:
            return []

        if boxes.dtype.kind == "i":
            boxes = boxes.astype("float")

        pick = []

        x1 = boxes[:, 0]
        y1 = boxes[:, 1]
        x2 = boxes[:, 2]
        y2 = boxes[:, 3]

        area = (x2 - x1 + 1) * (y2 - y1 + 1)
        idxs = np.argsort(y2)

        while len(idxs) > 0:
            last = len(idxs) - 1
            i = idxs[last]
            pick.append(i)

            xx1 = np.maximum(x1[i], x1[idxs[:last]])
            yy1 = np.maximum(y1[i], y1[idxs[:last]])
            xx2 = np.minimum(x2[i], x2[idxs[:last]])
            yy2 = np.minimum(y2[i], y2[idxs[:last]])

            w = np.maximum(0, xx2 - xx1 + 1)
            h = np.maximum(0, yy2 - yy1 + 1)

            overlap = (w * h) / area[idxs[:last]]

            idxs = np.delete(idxs, np.concatenate(([last],
                                                   np.where(overlap > overlapThresh)[0])))

        return boxes[pick].astype("int")
    except Exception as e:
        print("Exception occurred in non_max_suppression : {}".format(e))

def calculate_iou(box1, box2):
    """
    Calculates the intersection over union (IoU) between two bounding boxes.

    box1 and box2 should be in the format (xmin, ymin, xmax, ymax).

    Returns a float between 0 and 1 representing the IoU between the two boxes.
    """
    x1, y1, w1, h1 = box1
    x2, y2, w2, h2 = box2

    # Calculate intersection area
    intersection_area = max(0, min(x1 + w1, x2 + w2) - max(x1, x2)) * max(0, min(y1 + h1, y2 + h2) - max(y1, y2))

    # Calculate union area
    union_area = w1 * h1 + w2 * h2 - intersection_area

    # Calculate IoU
    iou = intersection_area / union_area if union_area > 0 else 0

    return iou
def calculate_iou_v2(box1, box2):
    ymin1, xmin1, ymax1, xmax1 = box1
    ymin2, xmin2, ymax2, xmax2 = box2
    xi1 = max(xmin1, xmin2)
    yi1 = max(ymin1, ymin2)
    xi2 = min(xmax1, xmax2)
    yi2 = min(ymax1, ymax2)
    inter_area = max(xi2 - xi1, 0) * max(yi2 - yi1, 0)
    box1_area = (ymax1 - ymin1) * (xmax1 - xmin1)
    box2_area = (ymax2 - ymin2) * (xmax2 - xmin2)
    union_area = box1_area + box2_area - inter_area
    iou = inter_area / union_area
    return iou

def calculate_distance(point1, point2):
    """
    Calculates the Euclidean distance between two points in 2D space.

    point1 and point2 should be tuples of the form (x, y).

    Returns a float representing the distance between the two points.
    """
    x1, y1 = point1
    x2, y2 = point2

    distance = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
    #distance = np.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

    return distance

def Estimate(bbox):
    # Convert bounding box coordinates to x and y coordinates of the center of the box
    x = (bbox[1] + bbox[3]) / 2
    y = (bbox[0] + bbox[2]) / 2
    
    # Use the x and y coordinates as input to the Kalman filter
    measured = np.array([[np.float32(x)], [np.float32(y)]])
    kf.correct(measured)
    
    predicted = kf.predict()
    return predicted

# Define the UKF transition function
def fx(x, dt):
    # state transition matrix
    F = np.array([[1, dt, 0, 0, 0, 0],
                  [0, 1, 0, 0, 0, 0],
                  [0, 0, 1, dt, 0, 0],
                  [0, 0, 0, 1, 0, 0],
                  [0, 0, 0, 0, 1, dt],
                  [0, 0, 0, 0, 0, 1]])
    x_pred = F @ np.concatenate((x, [0, 0]))
    return x_pred

def hx(x):
    return np.dot(H, x)

def selectBbox(frame):
    global w_first, h_first
    
    bbox = cv2.selectROI('Tracker', frame)  
    
    bbox = np.array(bbox, np.uint32)
    bbox[2] = bbox[0] + bbox[2]
    bbox[3] = bbox[1] + bbox[3]

    bbox = tuple(bbox)  
    cv2.destroyAllWindows()
    return bbox

def track_list_function(bboxes):
    global track_list
    track_list = []

    for a in range(len(boxes)):
        for bb,bbox in enumerate(bboxes):
            color = cv2.cvtColor(np.uint8([[[bb * 255 / len(bboxes), 128, 200]]]),
                                 cv2.COLOR_HSV2RGB).squeeze().tolist()

            x1 = int(bbox[0])
            y1 = int(bbox[1])
            x2 = int(bbox[2])
            y2 = int(bbox[3])
            x = int((x1+x2)/2)
            y = int((y1+y2)/2)

            print(track_list)
            print(target_list[counter][counter-anti_counter:])
            text = "ID {}".format(target)
            cv2.putText(img, str(text), (x, y - 30), cv2.FONT_HERSHEY_TRIPLEX,
                            0.7, (0, 0, 0), 1)
            cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)

def create_kalman_filter(x, y):
    # Create a Kalman filter for tracking the object's position
    # Initialize the state estimate with the x and y coordinates
    # Assume that the object is stationary, so set the velocity to 0
    # Set the measurement noise to a small value
    # Set the process noise to a larger value to allow for smooth tracking
    kf = cv2.KalmanFilter(4, 2)
    kf.statePre = np.array([[x], [y], [0], [0]], dtype=np.float32)
    kf.statePost = np.array([[x], [y], [0], [0]], dtype=np.float32)
    kf.measurementMatrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], dtype=np.float32)
    kf.processNoiseCov = np.array([[1e-2, 0, 0, 0], [0, 1e-2, 0, 0], [0, 0, 1e-1, 0], [0, 0, 0, 1e-1]], dtype=np.float32)
    kf.measurementNoiseCov = np.array([[1e-2, 0], [0, 1e-2]], dtype=np.float32)
    kf.errorCovPost = np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]], dtype=np.float32)
    
    return kf

# Define the function to create a new Kalman filter for a given set of initial values
def create_kalman_filter_v2(x, y):
    kf = cv2.KalmanFilter(4, 2)
    kf.measurementMatrix = np.array([[1, 0, 0, 0],
                                     [0, 1, 0, 0]], np.float32)

    kf.transitionMatrix = np.array([[1, 0, 1, 0],
                                    [0, 1, 0, 1],
                                    [0, 0, 1, 0],
                                    [0, 0, 0, 1]], np.float32)

    kf.processNoiseCov = np.array([[1, 0, 0, 0],
                                   [0, 1, 0, 0],
                                   [0, 0, 1, 0],
                                   [0, 0, 0, 1]], np.float32) * 0.03

    kf.statePost = np.array([[x], [y], [0], [0]], np.float32)
    return kf

#############################################################################################################################################
cv2.namedWindow(TITLE)
#cv2.setMouseCallback(TITLE, mousemove) # To get the mouse pixel position if it is necessary

#detection_graph, sess = detector_utils.load_inference_graph()
#############################################################################################################################################

# Define the Unscented Kalman Filter (UKF)
    #ukf = UKF(dim_x=4, dim_z=2, dt=dt, fx=fx, hx=hx, points=MerweScaledSigmaPoints(n=4, alpha=0.1, beta=2.0, kappa=1.0))
    #ukf = UnscentedKalmanFilter(dim_x=4, dim_z=2, dt=dt, fx=fx, hx=hx, points=MerweScaledSigmaPoints(n=4, alpha=0.1, beta=2.0, kappa=1.0))
    #ukf = UKF(dim_x=4, dim_z=2, dt=dt, fx=lambda x, dt: np.array([[1, dt, 0, 0], [0, 1, 0, 0], [0, 0, 1, dt], [0, 0, 0, 1]]) @ x, 
          #hx=lambda x: np.array([[x[0], x[2]]]), 
          #points=MerweScaledSigmaPoints(n=4, alpha=0.1, beta=2.0, kappa=1.0))
    
# Define the UKF for object tracking
ukf = UnscentedKalmanFilter(dim_x=4, dim_z=2, dt=dt, fx=fx, hx=hx,
                            points=MerweScaledSigmaPoints(n=4, alpha=0.1, beta=2.0, kappa=1.0))

#############################################################################################################################################
frameNum = 0

# Set the initial state of the video to play
play = True

######################################################

if __name__ == '__main__':

    #non_active_threshold = 15 # 15
    #active_threshold = 4 # 4
    #tracker = IouTracker.IouTracker(active_threshold=active_threshold, non_active_threshold=non_active_threshold) # class object

    track_list = []
    car_dict = {}
    # Initialize the list of Kalman filters and IDs for tracked objects
    kalman_filters = []
    object_ids = []

    car_dict = {'car_0': {}}

    # Initialize the start time and frame counter
    start_time = time.time()
    frame_counter = 0

    # Declare the fps_text variable and assign it a default value
    fps_text = "FPS: 0.00"

    # Initialize a dictionary to store the IDs and information for tracked objects
    tracked_objects = {}

    # Initialize a variable to keep track of the next available ID
    next_id = 0

    fps_start_time = datetime.datetime.now()
    fps = 0
    total_frames = 0

    # Set the initial state of the video to play
    play = True


    while True:
        #ret, frame = cap.read()
        #ret, frame = video.read() # Webcam
        ret, _,frame = video.read() # Video
        total_frames = total_frames + 1
        
        height, width, _ = frame.shape

        # Get the dimensions of the frame
        frame_height, frame_width, _ = frame.shape
        #height, width = frame.shape[:2]

        # Define the ROI with the same size and shape as the frame
        roi = frame[0:frame_height, 0:frame_width]

        #print(roi.shape)  # (360, 640, 3)
        
        # check for frame if Nonetype
        if frame is None or roi is None:
            break

        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        frame_expanded = np.expand_dims(frame_rgb, axis=0)


        # -> 2nd Approach: Perform the actual detection by running the model with the image as input
        (boxes, scores, classes, num) = sess.run(
            [detection_boxes, detection_scores, detection_classes, num_detections],
            feed_dict={image_tensor: frame_expanded})

        # Get the number of detected objects
        num_objects = int(num[0])

        # To get all information about detected objects 
            #print ([category_index.get(value) for index,value in enumerate(classes[0]) if scores[0,index] > 0.9])
           
        # This function returns "object_count_dict, bbox_coordinates_v1, class_object_name, class_object_score, detection_results_v0, coordinates_list, counter_for, image"
        object_counting, bbox_coordinates, class_object_name, class_object_score, detection_results, coordinates_list_int, counter_for, image = vis_util.visualize_boxes_and_labels_on_image_array_how_many_object_updated(
                            frame,
                            np.squeeze(boxes),
                            np.squeeze(classes).astype(np.int32),
                            np.squeeze(scores),
                            category_index,
                            instance_masks=None,
                            instance_boundaries=None,
                            keypoints=None,
                            use_normalized_coordinates=True,
                            max_boxes_to_draw=5,
                            min_score_thresh=.9,
                            agnostic_mode=False,
                            line_thickness=2, # 4
                            groundtruth_box_visualization_color='black',
                            skip_scores=False,
                            skip_labels=False)
        ##################
        # Display Results to check incoming output
        #print(object_counting)
        #print(bbox_coordinates)
        #print(class_object_name)
        #print(class_object_score)
        #print(detection_results)
        #print(coordinates_list_int)
        #print(counter_for)
        #print(image)
        ##################
 

        # The reason why we multiply the normalized bounding box coordinates by the image height and width is to convert the bounding box coordinates from a normalized format to pixel coordinates.
        # The normalized format used by many object detection models represents the coordinates of the bounding box as a fraction of the image size, with the values of ymin, xmin, ymax, and xmax ranging between 0 and 1.
        #width=1280
        #height=720

        #width=640
        #height=352
        
        # Camera Pixel
        #width=640 # Webcam Real-Time
        #height=360
        # Multiplying these normalized coordinates by the image height and width gives us the corresponding pixel coordinates of the bounding box. For example, if we have an image with height 480 pixels and width 640 pixels,
        # and a bounding box with normalized coordinates (ymin, xmin, ymax, xmax) = (0.2, 0.3, 0.6, 0.7), then we can convert these coordinates to pixel coordinates as follows:
        #ymin_pixel = ymin * height = 0.2 * 480 = 96
        #xmin_pixel = xmin * width = 0.3 * 640 = 192
        #ymax_pixel = ymax * height = 0.6 * 480 = 288
        #xmax_pixel = xmax * width = 0.7 * 640 = 448
        ymin = boxes[0][0][0]*height
        xmin = boxes[0][0][1]*width
        ymax = boxes[0][0][2]*height
        xmax = boxes[0][0][3]*width

        # array results of the boxes (turn the float into int)
        ymin = int(ymin)
        xmin = int(xmin)
        ymax = int(ymax)
        xmax = int(xmax)
        ######################################################################################################################################
        #To get the results of the detected objects on the image bbox_coordinates or from return parameter named coordinates_list_int
        box_all = np.squeeze(boxes)
        
        # Initialize the dictionary to store the bounding boxes and IDs for tracked objects
        car_dict = {}

        # Initialize the list of Kalman filters and IDs for tracked objects
        kalman_filters = []
        object_ids = []

        # Initialize a dictionary to store the IDs and information for tracked objects
        tracked_objects = {}

        # Initialize a variable to keep track of the next available ID
        next_id = 0

        # Initialize the dictionary to map car IDs to unique IDs
        id_map = {}
      
        
        # Iterate over the boxes, classes, and scores for each detected object
        for a in range(len(boxes)):
            for i, box in enumerate(boxes[0]):
                ymin = int(box[0]*height)
                xmin = int(box[1]*width)
                ymax = int(box[2]*height)
                xmax = int(box[3]*width)

                y1 = int(box[0]*height)
                x1 = int(box[1]*width)
                y2 = int(box[2]*height)
                x2 = int(box[3]*width)

                # If the detected object is a car with high confidence
                if classes[0][i] == 4 and scores[0][i] >= 0.9:
                    # Find the Kalman filter closest to the detected object
                    x_center = int((xmin + xmax)/2)
                    y_center = int((ymin + ymax)/2)

                    ################################ 
                    # Get the threshold values for the current object detection
                    x_threshold = x_center + 20
                    y_threshold = y_center + 20

                    # Check if the midpoint of the bounding box is within the threshold
                    #if abs(x_center - x_threshold) <= 20 and abs(y_center - y_threshold) <= 20:
                        # Add the bounding box to the dictionary
                    #    car_dict["car_{}".format(i)] = {
                    #        "bbox": [xmin, ymin, xmax, ymax],
                    #        "midpoint": (x_center, y_center),
                    #        "confidence": scores[0][i]
                    #    }
                    ################################ DATA ASSOCIATION #########################################   
                    if not kalman_filters:
                        closest_kf = create_kalman_filter(x_center, y_center)
                        kalman_filters.append(closest_kf)
                        closest_id = 0
                        object_ids.append(closest_id)
                        id_counter = 1
                    else:
                        distances = [np.linalg.norm(np.array([x_center, y_center]) - kf.statePost[:2]) for kf in kalman_filters]
                        min_distance = min(distances)
                        closest_kf = kalman_filters[np.argmin(distances)]
                        closest_id = object_ids[np.argmin(distances)]

                        if min_distance < 100:
                            closest_kf = kalman_filters[distances.index(min_distance)]
                            closest_id = object_ids[distances.index(min_distance)]
                        else:
                            closest_kf = create_kalman_filter(x_center, y_center)
                            kalman_filters.append(closest_kf)
                            closest_id = id_counter
                            object_ids.append(closest_id)
                            id_counter += 1

                    # Update the Kalman filter with the detected object's position
                    measurement = np.array([[x_center], [y_center]], dtype=np.float32)
                    closest_kf.predict()
                    closest_kf.correct(measurement)

                    # Get the updated position of the tracked object
                    x_kf, y_kf = closest_kf.statePost[:2]

                    # Create a dictionary entry for the tracked object
                    car_id = "car_{}".format(closest_id)
                    car_dict[car_id] = {
                        "bbox": [xmin, ymin, xmax, ymax],
                        "midpoint": (int(x_kf), int(y_kf)),
                        "confidence": scores[0][i],
                        "id": closest_id
                    }


                    ################################ 

                    ###########################
                    # Check if this car has been tracked before
                    car_id_tracking = id_map.get(i)
                    if car_id_tracking is None:
                                        # If not, generate a new unique ID for this car
                        car_id_tracking = "car_{}".format(next_id)
                        next_id += 1
                        id_map[i] = car_id_tracking

                        # Create a new dictionary entry for the tracked object
                        tracked_objects[car_id_tracking] = {
                            "bbox": [xmin, ymin, xmax, ymax],
                            "midpoint": (int(x_center), int(y_center)),
                            "confidence": scores[0][i],
                            "id": next_id-1
                        }

                        # Create a new Kalman filter and add it to the list
                        kf = create_kalman_filter(x_center, y_center)
                        kalman_filters.append(kf)
                        object_ids.append(car_id_tracking)
                    else:
                        # Otherwise, update the dictionary and Kalman filter for this car
                        index = object_ids.index(car_id_tracking)
                        tracked_object = tracked_objects[car_id_tracking]
                        kf = kalman_filters[index]

                        # Update the dictionary with the updated position, confidence score, and unique ID of the tracked object
                        tracked_object['midpoint'] = (int(x_center), int(y_center))
                        tracked_object['confidence'] = scores[0][i]
                        tracked_object['id'] = car_dict[car_id_tracking]['id']

                        # Update the Kalman filter with the detected object's position
                        measurement = np.array([[x_center], [y_center]], dtype=np.float32)
                        kf.predict()
                        kf.correct(measurement)

                    # Draw the bounding box and midpoint for the current car on the frame
                    #cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (0, 255, 0), 2)
                    #cv2.circle(frame, (int(x_kf), int(y_kf)), 2, (0, 0, 255), 2)
                    #cv2.putText(frame, "ID: {}".format(car_id), (xmin, ymin - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

                    # The condition that is important for maintaining stable tracking.
                    if len(car_dict) == len(tracked_objects):
                        # Display information for each tracked car
                        for i, car_id_dict in enumerate(list(tracked_objects.keys())[:5]):
                            if car_id_dict in car_dict:
                                # Retrieve the dictionary entry for the current car
                                car_info = tracked_objects[car_id_dict]

                                # Extract the bounding box coordinates and midpoint information for the current car
                                xmin, ymin, xmax, ymax = car_info['bbox']
                                midpoint = car_info['midpoint']

                                #tracked_objects[car_id_dict]['midpoint'] = (int(x_kf), int(y_kf))
                                #tracked_objects[car_id_dict]['id'] = car_dict[car_id_dict]['id']

                                if 'midpoint' in car_info:
                                    midpoint = car_info['midpoint']
                                    midpoint_int = (int(midpoint[0]), int(midpoint[1]))
                                    tracked_objects[car_id_dict]['midpoint'] = midpoint_int
                                    #cv2.circle(frame, midpoint_int, 2, (0, 0, 255), 2)

                                # Display the ID, confidence score, and unique ID of the current car on the frame
                                cv2.putText(frame, "ID: {}, Confidence: {:.2f}".format(car_id_dict, car_info['confidence']), (xmin, ymin-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
                     
                                # Draw the bounding box and midpoint for the current car on the frame
                                cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (0, 255, 0), 2)
                                cv2.circle(frame, midpoint_int, 2, (0, 0, 255), 2)

                                print("CAR DICT: ",car_dict)
                                print("TRACKED OBJECTS DICT: ",tracked_objects)
                    else:
                        # Display a warning if the number of keys in the two dictionaries is different
                        warning_text_1 = "Warning: The number of keys in car_dict and tracked_objects is different."
                        #print(warning_text_1)

                        # Get the dimensions of the frame
                        height, width = frame.shape[:2]

                        # Calculate the coordinates of the center of the frame
                        center_x = int(width / 2)
                        center_y = int(height / 2)

                        # Define the warning text
                        warning_text = "WARNING: Potential collision ahead!"

                        # Get the size of the warning text
                        size, _ = cv2.getTextSize(warning_text, cv2.FONT_HERSHEY_SIMPLEX, 1, 2)

                        # Calculate the position of the warning text
                        text_x = center_x - int(size[0] / 2)
                        text_y = center_y + int(size[1] / 2)
                            
                        cv2.putText(frame, warning_text_1, (text_x, text_y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)


                
                    ################################
                

           




        ######################################################################################################################################
        # Loop over the detected cars and create a new Kalman filter for each one
        
        
        ######################################################################################################################################
        ################################
        # Calculate the FPS
        #frame_counter += 1
        #if frame_counter % 10 == 0:
            #fps = frame_counter / (time.time() - start_time)
            #fps_text = "FPS: {:.2f}".format(fps)

        # Add the FPS text to the frame
        #cv2.putText(frame, fps_text, (10, frame.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)       

        fps_end_time = datetime.datetime.now()
        time_diff = fps_end_time - fps_start_time
        if time_diff.seconds == 0:
            fps = 0.0
        else:
            fps = (total_frames / time_diff.seconds)

        fps_text = "FPS: {:.2f}".format(fps)

        # Add the FPS text to the frame
        cv2.putText(frame, fps_text, (10, frame.shape[0] - 10), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, (0, 0, 255), 1) #(5, 30)
             
        #############################################################################################################################
        ################
        # Display the resulting image
        #print(object_counting)
        cv2.putText(frame, str(object_counting), (50,50), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, (0, 0, 255), 1)
        #cv2.putText(frame, str(nscore), (50,100), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0,0,255), 2)
        # All the results have been drawn on the frame, so it's time to display it.
        #cv2.imshow('Object detector', frame)
        cv2.imshow(TITLE, frame)
        #cv2.imshow('Output', cv2.resize(frame, (640,480)))
        #cv2.imshow("roi", roi)

        key = cv2.waitKey(1) 
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        elif key == ord('p'): # Press the spacebar to toggle play/pause
            cv2.waitKey(-1)   #wait until any key is pressed
            #play = not play
        elif key == ord('u'):
            boxToTarget = selectBbox(frame)
            print(boxToTarget)
            initialize= True

        cv2.imshow(TITLE, frame)


        frameNum += 1

        if cv2.waitKey(25) & 0xFF == ord('q'):
            cv2.destroyAllWindows()
            break

# Clean up
video.release()
cv2.destroyAllWindows()
