######## Video Object Detection Using Tensorflow-trained Classifier #########
#
# Author: Aykut SIRMA
# Date: 12/15/2022
# Description: 
# This program uses a TensorFlow-trained classifier to perform object detection.
# It loads the classifier and uses it to perform object detection on a video.
# It draws boxes, scores, and labels around the objects of interest in each
# frame of the video or real-time video feed from webcam or camera.

# Import packages
import os
import cv2
import numpy as np
import tensorflow as tf
import sys
import time
import math
import datetime

import uuid

# Import utilites
from utils import label_map_util
from utils import visualization_utils as vis_util

from kalman_filter import KalmanFilter
from tracker import *
from utils import VehicleTracker

from object_detection.utils import tensorflow_tracker

from filterpy.kalman import UnscentedKalmanFilter, MerweScaledSigmaPoints




# Create tracker object
tracker = EuclideanDistTracker()

# Name of the directory containing the object detection module we're using
MODEL_NAME = 'inference_graph_iha'
VIDEO_NAME = 'video/vtest.mp4'

# Grab path to current working directory
CWD_PATH = os.getcwd()

# Path to frozen detection graph .pb file, which contains the model that is used
# for object detection.
PATH_TO_CKPT = os.path.join(CWD_PATH,MODEL_NAME,'frozen_inference_graph.pb')

# Path to label map file
PATH_TO_LABELS = os.path.join(CWD_PATH,'training_iha','labelmap.pbtxt')

# Path to video
PATH_TO_VIDEO = os.path.join(CWD_PATH,VIDEO_NAME)

# Number of classes the object detector can identify
NUM_CLASSES = 16

TITLE = "Object Tracking and Mouse Tracking with Kalman Filter "
# frame = np.ones((800,800,3),np.uint8) * 255

# Kalman Filter used for mouse() function
current_measurement = None
current_prediction = None
kalman = None

# Real-Time Video feed to capture from Webcam
video = cv2.VideoCapture(0)

cv2.namedWindow(TITLE)
#cv2.setMouseCallback(TITLE, mousemove)


##################################################################################################################
# Initialize variables for tracking
prev_xmin = -1  # Initialize prev_xmin to a default value
prev_ymin = -1  # Initialize prev_ymin to a default value

# Define a global counter variable to assign unique IDs to cars
CAR_ID_COUNTER = 0

# To assign a unique ID for each detected object that will not repeat, you can use a counter variable that increments each time a new object is detected.
object_counter = 0

object_id = 0  # Initialize the object ID for single target
object_id_track = 0  # Initialize the object ID for single target

# Define a list to store the object IDs for each detected object
object_ids = []

# Initialize an empty dictionary to store object IDs and their corresponding bounding box coordinates
object_dict = {}
threshold = 30  # Failure detection threshold


############################################


# Kalman Filter
stateMatrix = np.zeros((4, 1), np.float32)  # [x, y, delta_x, delta_y]
estimateCovariance = np.eye(stateMatrix.shape[0])
transitionMatrix = np.array([[1, 0, 1, 0],[0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)
processNoiseCov = np.array([[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]], np.float32) * 0.001
measurementStateMatrix = np.zeros((2, 1), np.float32)
observationMatrix = np.array([[1,0,0,0],[0,1,0,0]],np.float32)
measurementNoiseCov = np.array([[1,0],[0,1]], np.float32) * 1
kalman = KalmanFilter(X=stateMatrix,
                      P=estimateCovariance,
                      F=transitionMatrix,
                      Q=processNoiseCov,
                      Z=measurementStateMatrix,
                      H=observationMatrix,
                      R=measurementNoiseCov)


# Initialize the Kalman Filter
kf = cv2.KalmanFilter(4, 2)
kf.measurementMatrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], np.float32)
kf.transitionMatrix = np.array([[1, 0, 1, 0], [0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)
kf.processNoiseCov = np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32) * 0.03
kf.measurementNoiseCov = np.array([[1, 0], [0, 1]], np.float32) * 0.00003

"""
if tf.test.gpu_device_name(): 
    print('Default GPU Device: {}'.format(tf.test.gpu_device_name()))
else:
    print("Please install GPU version of TF")
"""

config = tf.ConfigProto()
config.gpu_options.allow_growth=True
sess = tf.Session(config=config)


if tf.test.gpu_device_name(): 
    print('Default GPU Device: {}'.format(tf.test.gpu_device_name()))
else:
    print("Please install GPU version of TF")


# Load the label map.
# Label maps map indices to category names, so that when our convolution
# network predicts `4`, we know that this corresponds to `car`.
# Here we use internal utility functions, but anything that returns a
# dictionary mapping integers to appropriate string labels would be fine
label_map = label_map_util.load_labelmap(PATH_TO_LABELS)
categories = label_map_util.convert_label_map_to_categories(label_map, max_num_classes=NUM_CLASSES, use_display_name=True)
category_index = label_map_util.create_category_index(categories)

# Load the Tensorflow model into memory.
detection_graph = tf.Graph()
with detection_graph.as_default():
    od_graph_def = tf.GraphDef()
    with tf.gfile.GFile(PATH_TO_CKPT, 'rb') as fid:
        serialized_graph = fid.read()
        od_graph_def.ParseFromString(serialized_graph)
        tf.import_graph_def(od_graph_def, name='')

    sess = tf.Session(graph=detection_graph)

# Define input and output tensors (i.e. data) for the object detection classifier
# Input tensor is the image
# 0)
image_tensor = detection_graph.get_tensor_by_name('image_tensor:0')

# Output tensors are the detection boxes, scores, and classes
# Each box represents a part of the image where a particular object was detected
# 1)
detection_boxes = detection_graph.get_tensor_by_name('detection_boxes:0')

# Each score represents level of confidence for each of the objects.
# The score is shown on the result image, together with the class label.
# 2)
detection_scores = detection_graph.get_tensor_by_name('detection_scores:0')
# 3)
detection_classes = detection_graph.get_tensor_by_name('detection_classes:0')

# Number of objects detected
# 4)
num_detections = detection_graph.get_tensor_by_name('num_detections:0')

# Number of frames to capture
num_frames = 1 # the dataset had made for one frame per second so we make it "1" here


###########
# Check the current resolution of the camera
#width = video.get(cv2.CAP_PROP_FRAME_WIDTH)
#height = video.get(cv2.CAP_PROP_FRAME_HEIGHT)

# Print the current resolution
#print("Current webcam resolution: {} x {}".format(int(width), int(height)))
###########

###########
# Set the resolution to 1920 x 1080
#video.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
#video.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)

# Check the current resolution of the camera
#width = video.get(cv2.CAP_PROP_FRAME_WIDTH)
#height = video.get(cv2.CAP_PROP_FRAME_HEIGHT)

# Print the current resolution
#print("Current webcam resolution: {} x {}".format(int(width), int(height)))
###########

def calculate_iou(box1, box2):
    """
    Calculates the intersection over union (IoU) between two bounding boxes.

    box1 and box2 should be in the format (xmin, ymin, xmax, ymax).

    Returns a float between 0 and 1 representing the IoU between the two boxes.
    """
    x1, y1, w1, h1 = box1
    x2, y2, w2, h2 = box2

    # Calculate intersection area
    intersection_area = max(0, min(x1 + w1, x2 + w2) - max(x1, x2)) * max(0, min(y1 + h1, y2 + h2) - max(y1, y2))

    # Calculate union area
    union_area = w1 * h1 + w2 * h2 - intersection_area

    # Calculate IoU
    iou = intersection_area / union_area if union_area > 0 else 0

    return iou

def calculate_distance(point1, point2):
    """
    Calculates the Euclidean distance between two points in 2D space.

    point1 and point2 should be tuples of the form (x, y).

    Returns a float representing the distance between the two points.
    """
    x1, y1 = point1
    x2, y2 = point2

    distance = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

    return distance

fps_start_time = datetime.datetime.now()
fps = 0
total_frames = 0

while True:

    ret, frame = video.read()
    height, width, _ = frame.shape

    # Get the dimensions of the frame
    frame_height, frame_width, _ = frame.shape

    # Define the ROI with the same size and shape as the frame
    roi = frame[0:frame_height, 0:frame_width]

    #print(roi.shape)  # (360, 640, 3)
    
    # check for frame if Nonetype
    if frame is None or roi is None:
        break
    
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame_expanded = np.expand_dims(frame_rgb, axis=0)

    # Perform the actual detection by running the model with the image as input
    (boxes, scores, classes, num) = sess.run(
        [detection_boxes, detection_scores, detection_classes, num_detections],
        feed_dict={image_tensor: frame_expanded})

    
    # To get all information about detected objects 
            #print ([category_index.get(value) for index,value in enumerate(classes[0]) if scores[0,index] > 0.5])

    # This function returns "object_count_dict, bbox_coordinates_v1, class_object_name, class_object_score, detection_results_v0, coordinates_list, counter_for, image"
    object_counting, bbox_coordinates, class_object_name, class_object_score, detection_results, coordinates_list_int, counter_for, image = vis_util.visualize_boxes_and_labels_on_image_array_how_many_object_updated(
                        frame,
                        np.squeeze(boxes),
                        np.squeeze(classes).astype(np.int32),
                        np.squeeze(scores),
                        category_index,
                        instance_masks=None,
                        instance_boundaries=None,
                        keypoints=None,
                        use_normalized_coordinates=True,
                        max_boxes_to_draw=5, # 20
                        min_score_thresh=.8,
                        agnostic_mode=False,
                        line_thickness=2, # 4
                        groundtruth_box_visualization_color='black',
                        skip_scores=False,
                        skip_labels=False)


    # After performing object detection on a video frame

    # Obtain the measurements of the object's position
    box_target = np.squeeze(boxes)[0] # Assuming that there is only one detection in the image
    
    # box array is [ymin, xmin, ymax, xmax] which can be written as [y1,x1,y2,x2] too
    #ymin, xmin, ymax, xmax = box
    ymin_target, xmin_target, ymax_target, xmax_target = box_target

    # Convert the measurements to a 2x1 matrix
    current_measurement_target = np.array([[xmin_target + (xmax_target - xmin_target)/2], [ymin_target + (ymax_target - ymin_target)/2]])

    # Use the Kalman filter to predict the next state of the object
    current_prediction_target = kalman.predict()

    # Use the Kalman filter to update the estimate of the object's state
    kalman.correct(current_measurement_target)

    # Use the predicted state to draw a predicted box around the object in the video frame
    cv2.rectangle(frame, (int(current_prediction_target[0]-(xmax_target - xmin_target)/2), int(current_prediction_target[1]-(ymax_target - ymin_target )/2)),
                  (int(current_prediction_target[0]+(xmax_target - xmin_target)/2), int(current_prediction_target[1]+(ymax_target - ymin_target)/2)),
                  (0, 0, 255), 2)

    


    # Display Results to check incoming output
    #print(object_counting)
    #print(bbox_coordinates)
    #print(class_object_name)
    #print(class_object_score)
    #print(detection_results)
    #print(coordinates_list_int)
    #print(counter_for)
    #print(image)
    
    # Extract the bounding box coordinates from the detection output
    #bbox = detection_output['detection_boxes'][0]
    #bbox = coordinates_list_int
    
    # Pass the bounding box coordinates to the Kalman filter
    #predictedCoords = Estimate(bbox)
    
    # Draw the predicted position of the object on the frame
    #cv2.circle(frame, (int(predictedCoords[0]), int(predictedCoords[1])), 20, [0, 0, 255], 2, 8)
    
    ######################################################################################################################################
    ######################################################################################################################################
    # Draw the results of the detection (aka 'visulaize the results')
    #To get the results of the detected objects on the image with 1st way
    #def draw_bounding_box_on_image(image,    Go here to get 
    #width, height = image.size
    #height, width, channels = image.shape
    #height, width = frame.shape[:2]


    # The reason why we multiply the normalized bounding box coordinates by the image height and width is to convert the bounding box coordinates from a normalized format to pixel coordinates.
    # The normalized format used by many object detection models represents the coordinates of the bounding box as a fraction of the image size, with the values of ymin, xmin, ymax, and xmax ranging between 0 and 1.
    #width=1920
    #height=1080
    # Camera Pixel
    width=640
    height=360
    # Multiplying these normalized coordinates by the image height and width gives us the corresponding pixel coordinates of the bounding box. For example, if we have an image with height 480 pixels and width 640 pixels,
    # and a bounding box with normalized coordinates (ymin, xmin, ymax, xmax) = (0.2, 0.3, 0.6, 0.7), then we can convert these coordinates to pixel coordinates as follows:
    #ymin_pixel = ymin * height = 0.2 * 480 = 96
    #xmin_pixel = xmin * width = 0.3 * 640 = 192
    #ymax_pixel = ymax * height = 0.6 * 480 = 288
    #xmax_pixel = xmax * width = 0.7 * 640 = 448
    ymin = boxes[0][0][0]*height
    xmin = boxes[0][0][1]*width
    ymax = boxes[0][0][2]*height
    xmax = boxes[0][0][3]*width

    #https://stackoverflow.com/questions/60687483/how-to-give-a-unique-id-to-each-bounding-box-of-each-object-detected

    #print("Detected Object's Bounding Box'")
    #print('Top left Coodinates of Detected Object (x1,y1):' + str(xmin) + "," + str(ymin) )
    #print(xmin,ymin)
    #print('Bottom right Coodinates of Detected Object (x2,y2):' + str(xmax) + "," + str(ymax) )
    #print(xmax,ymax)

    # array results of the boxes (turn the float into int)
    ymin = int(ymin)
    xmin = int(xmin)
    ymax = int(ymax)
    xmax = int(xmax)

    #To get the results of the detected objects on the image bbox_coordinates coordinates_list_int
    box_all = np.squeeze(boxes)
    
    for a in range(len(boxes)):
        #https://www.geeksforgeeks.org/enumerate-in-python/
        for i,b in enumerate(boxes[0]):
            #print(b)
            #print(bbox_coordinates)
            #print(coordinates_list_int) # pixel coordinate
            ymin = (int(box_all[i,0]*height))
            xmin = (int(box_all[i,1]*width))
            ymax = (int(box_all[i,2]*height))
            xmax = (int(box_all[i,3]*width))

            y1 = (int(box_all[i,0]*height))
            x1 = (int(box_all[i,1]*width))
            y2 = (int(box_all[i,2]*height))
            x2 = (int(box_all[i,3]*width))

            #                  car
            if classes[0][i] == 4:
                if scores[0][i] >= 0.9:
                    # You can play with this calculation more if you like, but I am going to move on.
                    # box array is [ymin, xmin, ymax, xmax] which can be written as [y1,x1,y2,x2] too
                    # # # For debugging purposes, I would like to display this number on screen. To do this, I am going to display at the following coordinates:  
                    mid_x = (boxes[0][i][1]+boxes[0][i][3])/2
                    mid_y = (boxes[0][i][0]+boxes[0][i][2])/2

                    #mid_x_new = (return_1st_id[0] + return_1st_id[2])/2
                    #mid_y_new = (return_1st_id[1] + return_1st_id[3])/2

                    # Now, we want to measure the width of the detected object. We can do this by asking how many pixels-wide the object is. We can do this with:
                    # (x,y) = (x2 + x1)/2, (y2+y1)/2
                    (x_center,y_center) = int((x2 + x1)/2), int((y2+y1)/2)

                    #                  car
                    if(classes[0][i] == 4):
                        #cv2.putText(frame, str(i), (int(x_center), int(y_center)), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 255), 2)
                        cv2.circle(frame,(int(x_center),int(y_center)),3,(0,255,0),cv2.FILLED)
    ######################################################################################################################################

    # Define a list to store the object IDs for each detected object
    #object_ids = []

    # Reset the variables for a new tracking task
    #object_id = 0  # For single target
    #object_id_track = 0  # For multiple targets
    #object_ids = []  # For storing the object IDs

    # These two variables to reset depends on the task where
    # If we want to assign a unique ID to each detected object that will not repeat, we can use the object_counter variable to keep track of the number of objects detected so far, and increment it each time a new object is detected.
    # In this case, we should not reset object_counter to 0 before each new tracking task,
    # as we want the ID assigned to the new objects to be unique and not repeat the IDs of the objects tracked in the previous task.

    #object_dict = {}  # For storing the object IDs and their corresponding bounding box coordinates
    #object_counter = 0  # For assigning unique IDs to each detected object

    # Initialize an empty dictionary to store object IDs for each detected object
    # Initialize an empty dictionary to store object IDs for each detected object
    #object_dict = {}

    #for i, box in enumerate(boxes[0]):
        #class_id = int(classes[0][i])
        #score_val = scores[0][i]
            
        # Check if the detected object is a car and has a high enough detection score
        #if class_id == 4 and score_val >= 0.9:
                
            # Calculate the pixel coordinates of the bounding box
            #ymin = int(box[0] * height) # y1
            #xmin = int(box[1] * width)  # x1
            #ymax = int(box[2] * height) # y2
            #xmax = int(box[3] * width)  # x2

            # Track the object and assign a unique ID
            #object_id, xmin_ID, ymin_ID, xmax_ID, ymax_ID = tensorflow_tracker.track_object_updated_v3(object_id, i, xmin, ymin, xmax, ymax, object_dict, threshold)

            # Draw the object's ID and predicted bounding box on the image
            #cv2.rectangle(frame, (xmin_ID+3, ymin_ID+3), (xmax_ID-3, ymax_ID-3), (0, 255, 0), 2)
            #cv2.putText(frame, str(object_id), (xmin_ID, ymin_ID-20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)


    #################
    # Define the Kalman filter model parameters
    dt = 1.0  # time step
    A = np.array([[1, dt], [0, 1]])  # state transition matrix
    H = np.array([[1, 0]])  # observation matrix
    Q = np.eye(2) * 0.01  # process noise covariance matrix
    R = np.array([[0.1]])  # measurement noise covariance matrix
    x = np.zeros((2, 1))  # initial state vector
    P = np.eye(2) * 1000  # initial state covariance matrix

    # Define the object tracking variables
    box_all = np.squeeze(boxes)
    tracked_objects = {}
    object_ids = []
    object_counter = 0

    # Loop over the detected objects and track them using a Kalman filter
    for i, box in enumerate(box_all):
        ymin = int(box[0] * height)
        xmin = int(box[1] * width)
        ymax = int(box[2] * height)
        xmax = int(box[3] * width)
        
        class_id = classes[0][i]
        confidence = scores[0][i]
        
        if class_id == 4 and confidence >= 0.9:
            found_match = False
            
            for obj_id in object_ids:
                obj_info = tracked_objects[obj_id]
                prev_box = obj_info['box']
                prev_centroid = obj_info['centroid']
                prev_xmin, prev_ymin, prev_xmax, prev_ymax = map(int, prev_box * [height, width, height, width])
                
                iou = calculate_iou(box, prev_box)
                centroid = ((xmin + xmax) / 2, (ymin + ymax) / 2)
                distance = calculate_distance(centroid, prev_centroid)

                if iou > 0.5 and distance < 50:
                    # Update the tracked object with the current box and centroid
                    tracked_objects[obj_id]['box'] = box
                    tracked_objects[obj_id]['centroid'] = centroid
                    
                    # Predict the next state using the Kalman filter
                    x = np.dot(A, x)
                    P = np.dot(np.dot(A, P), A.T) + Q
                    z = np.array([[centroid[0]]])
                    y = z - np.dot(H, x)
                    S = np.dot(np.dot(H, P), H.T) + R
                    K = np.dot(np.dot(P, H.T), np.linalg.inv(S))
                    x = x + np.dot(K, y)
                    P = np.dot((np.eye(2) - np.dot(K, H)), P)
                    
                    # Draw the bounding box and ID on the image
                    ymin, xmin, ymax, xmax = map(int, box * [height, width, height, width])
                    cv2.rectangle(image, (xmin, ymin), (xmax, ymax), (0, 255, 0), 2)
                    cv2.putText(image, obj_id, (xmin, ymin - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
                    found_match = True
                    break
            
            #
            if not found_match:
                obj_id = str(object_counter)
                tracked_objects[obj_id] = {'box': box, 'centroid': ((xmin + xmax) / 2, (ymin + ymax) / 2)}
                
                # Initialize the Kalman filter state vector and covariance matrix
                x = np.zeros((2, 1))
                P = np.eye(2) * 1000
                
                # Draw the bounding box and ID on the image
                ymin, xmin, ymax, xmax = map(int, box * [height, width, height, width])
                cv2.rectangle(image, (xmin, ymin), (xmax, ymax), (0, 255, 0), 2)
                cv2.putText(image, obj_id, (xmin, ymin - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
                
                object_ids.append(obj_id)
                object_counter += 1
                prev_centroid = ((xmin + xmax) / 2, (ymin + ymax) / 2)
                
            # Update the Kalman filter state for the tracked objects
            for obj_id in object_ids:
                obj_info = tracked_objects[obj_id]
                box = obj_info['box']
                ymin, xmin, ymax, xmax = map(int, box * [height, width, height, width])
                prev_box = obj_info.get('prev_box', None)
                
                if prev_box is not None:
                    prev_ymin, prev_xmin, prev_ymax, prev_xmax = map(int, prev_box * [height, width, height, width])
                    iou = calculate_iou(box, prev_box)
                    centroid = obj_info['centroid']
                    distance = calculate_distance(centroid, prev_centroid)
                    
                    if iou > 0.5 and distance < 50:
                        # Update the tracked object with the current box and centroid
                        tracked_objects[obj_id]['box'] = box
                        tracked_objects[obj_id]['centroid'] = centroid
                        
                        # Predict the next state using the Kalman filter
                        x = np.dot(A, x)
                        P = np.dot(np.dot(A, P), A.T) + Q
                        z = np.array([[centroid[0]]])
                        y = z - np.dot(H, x)
                        S = np.dot(np.dot(H, P), H.T) + R
                        K = np.dot(np.dot(P, H.T), np.linalg.inv(S))
                        x = x + np.dot(K, y)
                        P = np.dot((np.eye(2) - np.dot(K, H)), P)
                        
                        # Draw the bounding box and ID on the image
                        cv2.rectangle(image, (xmin, ymin), (xmax, ymax), (0, 255, 0), 2)
                        cv2.putText(image, obj_id, (xmin, ymin - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
                    
                    # Save the previous state of the object for the next frame
                    tracked_objects[obj_id]['prev_box'] = box
                    tracked_objects[obj_id]['prev_centroid'] = centroid
        
    ######################################################################################################################################
    fps_end_time = datetime.datetime.now()
    time_diff = fps_end_time - fps_start_time
    if time_diff.seconds == 0:
        fps = 0.0
    else:
        fps = (total_frames / time_diff.seconds)

    fps_text = "FPS: {:.2f}".format(fps)

    # Add the FPS text to the frame
    cv2.putText(frame, fps_text, (10, frame.shape[0] - 10), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, (0, 0, 255), 1) #(5, 30)
    # 2. Object Tracking
    #boxes_ids = tracker.update(coordinates_list_int)
    #for box_id in boxes_ids:
        #x, y, w, h, id = box_id
        #cv2.putText(roi, str(id), (x, y - 15), cv2.FONT_HERSHEY_PLAIN, 2, (255, 0, 0), 2)
        #cv2.rectangle(roi, (x, y), (x + w, y + h), (0, 255, 0), 3)

    #######################################################################################################################################3   
    # Display the resulting image
    
    #print(object_counting)
    cv2.putText(frame, str(object_counting), (50,50), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0,0,255), 2)
    #cv2.putText(frame, str(nscore), (50,100), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0,0,255), 2)
    # All the results have been drawn on the frame, so it's time to display it.
    #cv2.imshow('Object detector', frame)
    cv2.imshow(TITLE, frame)
    #cv2.imshow('Output', cv2.resize(frame, (640,480)))
    #cv2.imshow("roi", roi)

    # Press 'q' to quit
    #if cv2.waitKey(1) == ord('q'):
        #break

    # check for 'q' key if pressed
    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break

# Clean up
video.release()
cv2.destroyAllWindows()
